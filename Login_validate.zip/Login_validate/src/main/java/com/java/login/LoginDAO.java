package com.java.login;

public interface LoginDAO {
	public String verifyOtp(Login login);
	public String loginDao(Login login);
}
